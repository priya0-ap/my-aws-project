import json
import boto3
import logging

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('MyTable')

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event))

    try:
        # Check if 'fieldName' exists in the event
        if 'fieldName' not in event:
            raise ValueError("Missing 'fieldName' in event")

        if event['fieldName'] == 'createItem':
            item = {
                'id': event['arguments']['id'],
                'name': event['arguments']['name'],
                'description': event['arguments']['description']
            }
            response = table.put_item(Item=item)
            logger.info("Item created: %s", json.dumps(item))
            return item
        
        elif event['fieldName'] == 'getItem':
            key = {'id': event['arguments']['id']}
            response = table.get_item(Key=key)
            logger.info("Retrieved item: %s", json.dumps(response))
            return response.get('Item')
        
        else:
            logger.error("Unknown field: %s", event['fieldName'])
            return {"error": "Unknown field"}
    except Exception as e:
        logger.error("Error processing event: %s", e)
        return {"error": str(e)}
